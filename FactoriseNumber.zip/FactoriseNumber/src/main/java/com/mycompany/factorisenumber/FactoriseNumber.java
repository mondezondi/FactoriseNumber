/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.factorisenumber;
import java.util.Scanner;

/**
 *
 * @author Lenovo-User
 */
public class FactoriseNumber {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();
        scanner.close();

        System.out.print("Prime factors of " + number + " are: ");
        factorize(number);
    }

    // Function to factorize a number and print its prime factors
    public static void factorize(int number) {
        if (number <= 1) {
            System.out.println("No prime factors (number should be greater than 1).");
            return;
        }

        for (int i = 2; i <= number; i++) {
            while (number % i == 0) {
                System.out.print(i + " ");
                number /= i;
            }
        }
    }
}